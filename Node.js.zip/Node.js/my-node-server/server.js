const http = require('http');
const url = require('url');

const pageViews = {
    '/': 0,
    '/about': 0
};

const server = http.createServer((req, res) => {
    const urlParts = url.parse(req.url, true);
    const path = urlParts.pathname;

    if (path === '/') {
        pageViews['/']++;
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write('<h1>Welcome to the homepage</h1>');
        res.write(`<p>Page views: ${pageViews['/']}</p>`);
        res.write('<a href="/about">About Us</a>');
        res.end();
    } else if (path === '/about') {
        pageViews['/about']++;
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write('<h1>About Us</h1>');
        res.write(`<p>Page views: ${pageViews['/about']}</p>`);
        res.write('<a href="/">Back to Homepage</a>');
        res.end();
    } else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.write('<h1>404 Not Found</h1>');
        res.end();
    }
});

const PORT = 3000;

server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
});
